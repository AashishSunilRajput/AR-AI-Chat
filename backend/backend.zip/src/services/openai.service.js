import OpenAI from "openai";

class OpenAIService {
  constructor() {
    this.client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }

  async generateReply({
    message,
    model = "gpt-5-mini",
    maxTokens = 1000,
  }) {
    try {
      const response = await this.client.chat.completions.create({
        model,

        messages: [
          {
            role: "user",
            content: message,
          },
        ],

        max_completion_tokens: maxTokens,
      });

      return {
        message: response.choices[0].message.content,
        usage: response.usage,
      };
    } catch (error) {
      console.error("OpenAI Error:", error);

      throw new Error(
        error?.error?.message || error.message || "Failed to generate AI reply"
      );
    }
  }
}

export default new OpenAIService();